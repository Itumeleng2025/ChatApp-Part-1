package chatapp.part.pkg1;


import org.junit.Test;
import static org.junit.Assert.*;

public class LoginTest {

    @Test
    public void testValidateUsername_valid() {
        assertTrue(Registration.validateUsername("abc_d")); // underscore + <= 5 chars
    }

    @Test
    public void testValidateUsername_invalidNoUnderscore() {
        assertFalse(Registration.validateUsername("abcd")); // no underscore
    }

    @Test
    public void testValidateUsername_invalidTooLong() {
        assertFalse(Registration.validateUsername("abc_def")); // 7 chars, too long
    }

    @Test
    public void testValidatePassword_valid() {
        assertTrue(Registration.validatePassword("Abcdef1@")); // meets rules
    }

    @Test
    public void testValidatePassword_invalidNoUppercase() {
        assertFalse(Registration.validatePassword("abcdef1@"));
    }

    @Test
    public void testValidatePassword_invalidNoNumber() {
        assertFalse(Registration.validatePassword("Abcdefg@"));
    }

    @Test
    public void testValidatePassword_invalidNoSpecialChar() {
        assertFalse(Registration.validatePassword("Abcdefg1"));
    }

    @Test
    public void testValidatePassword_invalidTooShort() {
        assertFalse(Registration.validatePassword("Ab1@")); // too short
    }

    @Test
    public void testValidatePhone_valid() {
        assertTrue(Registration.validatePhone("+27123456789")); // correct format
    }

    @Test
    public void testValidatePhone_invalidMissingCode() {
        assertFalse(Registration.validatePhone("0123456789"));
    }

    @Test
    public void testValidatePhone_invalidTooShort() {
        assertFalse(Registration.validatePhone("+27123"));
    }

    @Test
    public void testValidateFullName_valid() {
        assertTrue(Registration.validateFullName("Itumeleng Nyakane"));
    }

    @Test
    public void testValidateFullName_invalidEmpty() {
        assertFalse(Registration.validateFullName(""));
    }

    @Test
    public void testValidateFullName_invalidNull() {
        assertFalse(Registration.validateFullName(null));
    }

    @Test
    public void testRegister_validUser() throws Exception {
        UserCredentials user = Registration.register(
                "Itumeleng Nyakane",
                "abc_d",
                "Abcdef1@",
                "+27123456789"
        );
        assertNotNull(user);
        assertEquals("abc_d", user.getUsername());
    }

    @Test
    public void testRegister_invalidUsername() {
        try {
            Registration.register("Itumeleng", "abcd", "Abcdef1@", "+27123456789");
            fail("Expected RegistrationException");
        } catch (Registration.RegistrationException ex) {
            assertEquals("Username must contain an underscore and be no more than 5 characters.", ex.getMessage());
        } catch (Exception ex) {
            fail("Unexpected exception: " + ex);
        }
    }

    @Test
    public void testRegister_invalidPassword() {
        try {
            Registration.register("Itumeleng", "abc_d", "abcdefg1", "+27123456789");
            fail("Expected RegistrationException");
        } catch (Registration.RegistrationException ex) {
            assertEquals("Password must be at least 8 characters, include uppercase, number, and special character.", ex.getMessage());
        } catch (Exception ex) {
            fail("Unexpected exception: " + ex);
        }
    }

    @Test
    public void testRegister_invalidPhone() {
        try {
            Registration.register("Itumeleng", "abc_d", "Abcdef1@", "0123456789");
            fail("Expected RegistrationException");
        } catch (Registration.RegistrationException ex) {
            assertEquals("Phone number must start with +27 followed by 9 digits.", ex.getMessage());
        } catch (Exception ex) {
            fail("Unexpected exception: " + ex);
        }
    }

    @Test
    public void testRegister_invalidFullName() {
        try {
            Registration.register("", "abc_d", "Abcdef1@", "+27123456789");
            fail("Expected RegistrationException");
        } catch (Registration.RegistrationException ex) {
            assertEquals("Full name must not be empty.", ex.getMessage());
        } catch (Exception ex) {
            fail("Unexpected exception: " + ex);
        }
    }
}
