/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chatapp.part.pkg1;


/**
 *
 * @author ST10445362 Nyakane Itumeleng
 */
import java.util.Objects;
import javax.swing.*;
import java.awt.*;

// Utility class for login authentication and GUI
public class Login {

    private Login() {
        throw new UnsupportedOperationException("Utility class");
    }

    public static boolean authenticate(UserCredentials user, String username, String password) {
        Objects.requireNonNull(user, "UserCredentials must not be null");
        Objects.requireNonNull(username, "Username must not be null");
        Objects.requireNonNull(password, "Password must not be null");

        if (!user.getUsername().equals(username)) {
            return false;
        }

        return constantTimeEquals(user.getPassword(), password);
    }

    private static boolean constantTimeEquals(String a, String b) {
        if (a == null || b == null) return false;
        if (a.length() != b.length()) return false;

        int result = 0;
        for (int i = 0; i < a.length(); i++) {
            result |= a.charAt(i) ^ b.charAt(i);
        }
        return result == 0;
    }

    public static void launchLoginGUI(UserCredentials user) {
        JFrame frame = new JFrame("Login");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(350, 200);
        frame.setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5,5,5,5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Username
        JLabel userLabel = new JLabel("Username:");
        gbc.gridx = 0; gbc.gridy = 0;
        frame.add(userLabel, gbc);

        JTextField userField = new JTextField(15);
        gbc.gridx = 1; gbc.gridy = 0;
        frame.add(userField, gbc);

        // Password
        JLabel passLabel = new JLabel("Password:");
        gbc.gridx = 0; gbc.gridy = 1;
        frame.add(passLabel, gbc);

        JPasswordField passField = new JPasswordField(15);
        gbc.gridx = 1; gbc.gridy = 1;
        frame.add(passField, gbc);

        // Result label
        JLabel resultLabel = new JLabel(" ");
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        frame.add(resultLabel, gbc);

        // Login button
        JButton loginButton = new JButton("Login");
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        frame.add(loginButton, gbc);

        // Action
        loginButton.addActionListener(e -> {
            String username = userField.getText().trim();
            String password = new String(passField.getPassword());

            if (username.isEmpty() || password.isEmpty()) {
                resultLabel.setText("Please enter username and password.");
                resultLabel.setForeground(Color.RED);
                return;
            }

            if (user == null) {
                resultLabel.setText("No registered user yet. Please register first.");
                resultLabel.setForeground(Color.RED);
                return;
            }

            boolean authenticated = authenticate(user, username, password);
            if (authenticated) {
                resultLabel.setText("<html>Login successful!<br>Phone: " + user.getPhoneNumber() + "</html>");
                resultLabel.setForeground(new Color(0, 128, 0));
            } else {
                resultLabel.setText("Invalid username or password.");
                resultLabel.setForeground(Color.RED);
            }
        });

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
