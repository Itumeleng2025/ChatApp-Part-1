/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chatapp.part.pkg1;


/**
 *
 * @author ST10445362 Nyakane Itumeleng
 */
import java.util.Objects;
import javax.swing.*;
import java.awt.*;

public class Login {

    // Private constructor to prevent instantiation of this utility class
    private Login() {
        throw new UnsupportedOperationException("Utility class");
    }

    /**
     * Authenticate the user by comparing username and password.
     * Uses constant-time comparison for password to prevent timing attacks.
     *
     * @param user     The UserCredentials object containing stored username and password
     * @param username The username input to check
     * @param password The password input to check
     * @return true if username and password match, false otherwise
     */
    public static boolean authenticate(UserCredentials user, String username, String password) {
        Objects.requireNonNull(user, "User  Credentials must not be null");
        Objects.requireNonNull(username, "Username must not be null");
        Objects.requireNonNull(password, "Password must not be null");

        // Check if username matches
        if (!user.getUsername().equals(username)) {
            return false;
        }

        // Check password using constant-time comparison
        return constantTimeEquals(user.getPassword(), password);
    }

    /**
     * Compares two strings in constant time to prevent timing attacks.
     *
     * @param a First string
     * @param b Second string
     * @return true if both strings are equal, false otherwise
     */
    private static boolean constantTimeEquals(String a, String b) {
        if (a == null || b == null) return false;
        if (a.length() != b.length()) return false;

        int result = 0;
        for (int i = 0; i < a.length(); i++) {
            // XOR each character and OR into result
            result |= a.charAt(i) ^ b.charAt(i);
        }
        return result == 0;
    }

    /**
     * Launches the login GUI window.
     * Provides fields for username and password input and a login button.
     * Displays popup messages for success or error feedback.
     *
     * @param user The UserCredentials object to authenticate against
     */
    public static void launchLoginGUI(UserCredentials user) {
        JFrame frame = new JFrame("Login");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(350, 200);
        frame.setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5,5,5,5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Username label and text field
        JLabel userLabel = new JLabel("Username:");
        gbc.gridx = 0; gbc.gridy = 0;
        frame.add(userLabel, gbc);

        JTextField userField = new JTextField(15);
        gbc.gridx = 1; gbc.gridy = 0;
        frame.add(userField, gbc);

        // Password label and password field
        JLabel passLabel = new JLabel("Password:");
        gbc.gridx = 0; gbc.gridy = 1;
        frame.add(passLabel, gbc);

        JPasswordField passField = new JPasswordField(15);
        gbc.gridx = 1; gbc.gridy = 1;
        frame.add(passField, gbc);

        // Login button spanning two columns
        JButton loginButton = new JButton("Login");
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        frame.add(loginButton, gbc);

        // Action listener for login button click
        loginButton.addActionListener(e -> {
            String username = userField.getText().trim();
            String password = new String(passField.getPassword());

            // Check for empty input fields
            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(frame,
                        "Please enter username and password.",
                        "Input Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Check if user credentials are available
            if (user == null) {
                JOptionPane.showMessageDialog(frame,
                        "No registered user yet. Please register first.",
                        "User  Not Found",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Authenticate user input
            boolean authenticated = authenticate(user, username, password);
            if (authenticated) {
                JOptionPane.showMessageDialog(frame,
                        "Login successful!\nPhone: " + user.getPhoneNumber(),
                        "Success",
                        JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(frame,
                        "Invalid username or password.",
                        "Authentication Failed",
                        JOptionPane.ERROR_MESSAGE);
            }
        });

        // Center the frame on screen and make it visible
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}