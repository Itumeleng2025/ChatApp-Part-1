/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chatapp.part.pkg1;

/**
 *
 * @author ST10445362 Nyakane Itumeleng
 */
// Welcome.java
// Swing GUI for Welcome screen
import javax.swing.*;
import java.awt.*;

public class Welcome extends JFrame {

    public Welcome(Runnable onClose) {
        setTitle("Welcome Screen");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        JLabel label = new JLabel("Welcome to OrbitOne App!", SwingConstants.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 18));
        add(label);

        // Center the window on screen
        setLocationRelativeTo(null);

        // Show window
        setVisible(true);

        // Close the welcome screen automatically after 3 seconds and run callback
        Timer timer = new Timer(3000, e -> {
            dispose();
            if (onClose != null) {
                onClose.run();
            }
        });
        timer.setRepeats(false); // Important: fire only once
        timer.start();
    }

    /**
     * Launch the welcome screen and execute a callback after it closes.
     */
    public static void showWelcomeScreen(Runnable onClose) {
        SwingUtilities.invokeLater(() -> new Welcome(onClose));
    }
}