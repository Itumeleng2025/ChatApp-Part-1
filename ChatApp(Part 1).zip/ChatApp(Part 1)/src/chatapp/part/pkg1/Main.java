/*

 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chatapp.part.pkg1;

/**
 *
 * @author ST10445362 Nyakane Itumeleng 
 */
public class Main {
    public static void main(String[] args) {
        // Launch the welcome screen first
        Welcome.showWelcomeScreen(() -> {
            // After welcome screen closes, launch registration GUI
            Registration.launchRegistrationGUI();
        });
    }
}