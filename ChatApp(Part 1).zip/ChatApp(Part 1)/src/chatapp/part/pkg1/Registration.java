/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chatapp.part.pkg1;

/**
 *
 * @author ST10445362 Nyakane Itumeleng
 */
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.Objects;
import java.util.regex.Pattern;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JOptionPane;

public class Registration {

    private static final Pattern USERNAME_PATTERN = Pattern.compile(".*_.*");
    private static final int MAX_USERNAME_LENGTH = 5;
    private static final Pattern PASSWORD_PATTERN =
            Pattern.compile("^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}$");
    private static final Pattern PHONE_PATTERN = Pattern.compile("^\\+27\\d{9}$");

    // Store the registered user (null if none registered yet)
    private static UserCredentials registeredUser  = null;

    private Registration() {
        throw new UnsupportedOperationException("Utility class");
    }

    public static boolean validateUsername(String username) {
        if (username == null) return false;
        if (username.length() > MAX_USERNAME_LENGTH) return false;
        return USERNAME_PATTERN.matcher(username).find();
    }

    public static boolean validatePassword(String password) {
        if (password == null) return false;
        return PASSWORD_PATTERN.matcher(password).matches();
    }

    public static boolean validatePhone(String phone) {
        if (phone == null) return false;
        return PHONE_PATTERN.matcher(phone).matches();
    }

    public static boolean validateFullName(String fullName) {
        return fullName != null && !fullName.trim().isEmpty();
    }

    public static UserCredentials register(
            String fullName, String username, String password, String phone
    ) throws RegistrationException {
        Objects.requireNonNull(fullName, "Full name must not be null");
        Objects.requireNonNull(username, "Username must not be null");
        Objects.requireNonNull(password, "Password must not be null");
        Objects.requireNonNull(phone, "Phone number must not be null");

        if (!validateFullName(fullName)) {
            throw new RegistrationException("Full name must not be empty.");
        }
        if (!validateUsername(username)) {
            throw new RegistrationException("Username must contain an underscore and be no more than 5 characters.");
        }
        if (!validatePassword(password)) {
            throw new RegistrationException("Password must be at least 8 characters, include uppercase, number, and special character.");
        }
        if (!validatePhone(phone)) {
            throw new RegistrationException("Phone number must start with +27 followed by 9 digits.");
        }

        // Create and store the registered user
        registeredUser  = new UserCredentials(fullName, username, password, phone);
        return registeredUser ;
    }

    public static class RegistrationException extends Exception {
        public RegistrationException(String message) {
            super(message);
        }
    }

    public static void launchRegistrationGUI() {
        JFrame frame = new JFrame("User  Registration");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(450, 400);
        frame.setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Full Name
        JLabel fullNameLabel = new JLabel("Full Name:");
        gbc.gridx = 0; gbc.gridy = 0;
        frame.add(fullNameLabel, gbc);

        JTextField fullNameField = new JTextField(20);
        gbc.gridx = 1; gbc.gridy = 0;
        frame.add(fullNameField, gbc);

        // Username
        JLabel userLabel = new JLabel("Username:");
        gbc.gridx = 0; gbc.gridy = 1;
        frame.add(userLabel, gbc);

        JTextField userField = new JTextField(20);
        gbc.gridx = 1; gbc.gridy = 1;
        frame.add(userField, gbc);

        // Password
        JLabel passLabel = new JLabel("Password:");
        gbc.gridx = 0; gbc.gridy = 2;
        frame.add(passLabel, gbc);

        JPasswordField passField = new JPasswordField(20);
        gbc.gridx = 1; gbc.gridy = 2;
        frame.add(passField, gbc);

        // Confirm Password
        JLabel confirmPassLabel = new JLabel("Confirm Password:");
        gbc.gridx = 0; gbc.gridy = 3;
        frame.add(confirmPassLabel, gbc);

        JPasswordField confirmPassField = new JPasswordField(20);
        gbc.gridx = 1; gbc.gridy = 3;
        frame.add(confirmPassField, gbc);

        // Phone number
        JLabel phoneLabel = new JLabel("Phone (+27XXXXXXXXX):");
        gbc.gridx = 0; gbc.gridy = 4;
        frame.add(phoneLabel, gbc);

        JTextField phoneField = new JTextField(20);
        gbc.gridx = 1; gbc.gridy = 4;
        frame.add(phoneField, gbc);

        // Buttons
        JButton registerButton = new JButton("Register");
        gbc.gridx = 0; gbc.gridy = 5;
        frame.add(registerButton, gbc);

        JButton loginButton = new JButton("Login");
        gbc.gridx = 1; gbc.gridy = 5;
        frame.add(loginButton, gbc);

        // Register button action
        registerButton.addActionListener(e -> {
            String fullName = fullNameField.getText().trim();
            String username = userField.getText().trim();
            String password = new String(passField.getPassword());
            String confirmPassword = new String(confirmPassField.getPassword());
            String phone = phoneField.getText().trim();

            try {
                if (!password.equals(confirmPassword)) {
                    throw new RegistrationException("Passwords do not match.");
                }

                UserCredentials newUser  = register(fullName, username, password, phone);

                JOptionPane.showMessageDialog(frame,
                        "Registration successful!",
                        "Success",
                        JOptionPane.INFORMATION_MESSAGE);

                frame.dispose();
                Login.launchLoginGUI(newUser ); // take to login with registered user
            } catch (RegistrationException ex) {
                JOptionPane.showMessageDialog(frame,
                        ex.getMessage(),
                        "Registration Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        });

        // Login button action
        loginButton.addActionListener(e -> {
            if (registeredUser  == null) {
                JOptionPane.showMessageDialog(frame,
                        "No registered user found. Please register first.",
                        "No User Registered",
                        JOptionPane.WARNING_MESSAGE);
            } else {
                frame.dispose();
                Login.launchLoginGUI(registeredUser );
            }
        });

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}